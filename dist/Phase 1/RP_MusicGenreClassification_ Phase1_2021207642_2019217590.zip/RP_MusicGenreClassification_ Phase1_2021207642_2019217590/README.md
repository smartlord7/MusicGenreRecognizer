# Music Genre Classification

This project is focused on the task of music genre classification using machine learning techniques. The source code is implemented in Matlab and it contains several pattern recognition techniques such as Random Forests, Minimum Distance Classifiers, etc.. Additionally, feature reduction techniques such as Principal Component Analysis (PCA), Linear Discriminant Analysis (LDA), Kruskal-Wallis are also implemented.

## Directories

- `plots`: this directory contains the generated graphs, confusion matrices, correlation matrices, and other visualizations.
- `doc`: this directory contains the project report and results compiled in Excel.
- `src`: this directory contains the source code implemented in Matlab.

## Authors

- Sancho Amaral Simões (2019217590)
- Jorge Júnior Rodrigues Martins (2021207642)

## Future Work

This is a preliminary version of the project and much future work is expected to be done, such as better documentation and code refactoring, more complete report, more and more advanced classification and feature reduction techniques, class balancing, graphical interface, more complete classifier evaluation, among others.